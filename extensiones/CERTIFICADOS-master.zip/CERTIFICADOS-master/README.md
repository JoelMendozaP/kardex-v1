CERTIFICADOS
============

1.- **GENERAR CERTIFICADOS DE EVENTOS EN PDF**


2.- **REQUISITOS**

apache2, php5, mysql-server, fpdf 1.7

3.- **BASE DE DATOS**

La estructura de la base de datos son:

a. db_ven01 (base de datos)   
b. nacional (tabla)   
c. primer_nombre, primer_apellido, cedula (atributos)   


4.- **SERVIDOR**

apache2 con el modulo de php5

5.- **LIBRERIA FPDF**

Fpdf es una biblioteca escrita en lenguaje de programación PHP que permite crear archivos en formato PDF
sin ningún requerimiento adicional. Es gratuita, y su licencia permite que sea modificada libremente.
